<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Usuarios</h1>

    <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-primary justify-content-end mt-3">Agregar Usuario</a>
    <br>
    <br>
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <div class="table-responsive">
        <table id="my-table" class="table table-bordered">
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Email</th>
                    <th>Rol</th>
                    <th>Editar</th>
                    <th>Eliminar</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e(implode(', ', $user->getRoleNames()->toArray())); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.users.edit', $user)); ?>"
                                class="btn btn-sm btn-warning">Editar Roles</a>

                        </td>
                        <td>

                            <form id="delete-entry-form-<?php echo e($user->id); ?>"
                                action="<?php echo e(route('user.destroy', $user->id)); ?>" method="POST"
                                style="display: inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button onclick="eliminarEntrada(event, <?php echo e($user->id); ?>)" type="button"
                                    class="btn btn-danger btn-sm">Eliminar</button>
                            </form>


                        </td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4">No se encontraron categorías.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>




    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.0/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.0/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        function eliminarEntrada(event, usersId) {
            event.preventDefault(); // Evitar el envío automático del formulario

            Swal.fire({
                title: '¿Estás seguro que deseas eliminar este registro?',
                text: '¡No podrás revertir esta acción!',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Sí, eliminar'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Enviar el formulario de eliminación
                    document.getElementById(`delete-entry-form-${usersId}`).submit();
                }
            });
        }
    </script>


    <!-- Script para inicializar DataTables -->
    <script>
        $(document).ready(function() {
            $('#my-table').DataTable({
                "paging": true,
                "searching": true,
                "ordering": true,
                "info": true,
                "lengthChange": true,
                "pageLength": 10,
                "language": {
                    "processing": "Procesando...",
                    "lengthMenu": "Mostrar _MENU_ registros por página",
                    "zeroRecords": "No se encontraron resultados",
                    "info": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_",
                    "infoEmpty": "Mostrando 0 registros",
                    "infoFiltered": "(filtrado de _MAX_ registros)",
                    "paginate": {
                        "first": "Primero",
                        "last": "Último",
                        "next": "Siguiente",
                        "previous": "Anterior"
                    },
                    "search": "Buscar:"
                }
            });
        });
    </script>

    <script>
        // Script para confirmar eliminación
        function confirmDelete() {
            return confirm('¿Estás seguro de que deseas eliminar este usuario?');
        }
    </script>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Videos\Documentos\ciclo II 2024\sistema-inventario\resources\views/admin/users/index.blade.php ENDPATH**/ ?>