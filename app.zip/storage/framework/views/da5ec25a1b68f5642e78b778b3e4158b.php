

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Seleccionar Cierre de Inventario</h1>

    <form action="<?php echo e(route('inventario.cierre-detalle')); ?>" method="GET">
        <div class="form-group">
            <label for="fecha_cierre">Seleccione una fecha de cierre:</label>
            <select name="fecha_cierre" id="fecha_cierre" class="form-control" required>
                <option value="">Seleccione una fecha</option>
                <?php $__currentLoopData = $fechasCierres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fecha): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($fecha->fecha_cierre); ?>"><?php echo e(\Carbon\Carbon::parse($fecha->fecha_cierre)->format('d-m-Y')); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <button type="submit" class="btn btn-primary mt-3">Ver Cierre</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Videos\Documentos\ciclo II 2024\sistema-inventario\resources\views/inventario/cierres.blade.php ENDPATH**/ ?>