

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Detalle de Producto</h1>

    <table class="table table-striped">
       
        <tr>
            <td><strong>Producto:</strong></td>
            <td><?php echo e($nombre_producto); ?></td>
        </tr>
        <tr>
            <td><strong>Codigo:</strong></td>
            <td><?php echo e($codigo); ?></td>
        </tr>
        <tr>
            <td><strong>Costo Promedio:</strong></td>
            <td>$<?php echo e(number_format($promedioPrecioCompra, 2)); ?></td>
        </tr>
        <tr>
            <td><strong>Saldo Monetario:</strong></td>
            <td>$<?php echo e($totalSaldoCompra); ?></td>
        </tr>
        <tr>
            <td><strong>Stock:</strong></td>
            <td><?php echo e($totalStock); ?></td>
        </tr>
    </table>

    <?php if(!empty($entradas) && count($entradas) > 0): ?>
        <table class="table table-bordered mt-4">
            <thead>
                <tr>
                    <th class="bg-success">Fecha Entrada</th>
                    <th class="bg-success">Descripción</th>
                    <th class="bg-success">Proveedor</th>
                    <th class="bg-success">Entradas</th>
                    <th class="bg-success">Salidas</th>
                    <th class="bg-success">Stock</th>
                    <th class="bg-success">Unidad medida</th>
                    <th class="bg-success">Precio de Compra</th>
                    <th class="bg-success">Saldo Compra</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $entradas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entrada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($entrada['fecha_ingreso']); ?></td>
                        <td><?php echo e($entrada['descripcion']); ?></td>
                        <td><?php echo e($entrada['proveedor']); ?></td>
                        <td><?php echo e($entrada['entradas']); ?></td>
                        <td><?php echo e($entrada['salidas']); ?></td>
                        <td><?php echo e($entrada['stock']); ?></td>
                        <td><?php echo e($entrada['unidad_medida']); ?></td>
                        <td>$<?php echo e($entrada['precio_compra']); ?></td>
                        <td>$<?php echo e($entrada['saldo_compra']); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="3"><strong>Totales:</strong></td>
                    <td><strong><?php echo e($totalEntradas); ?></strong></td>
                    <td><strong><?php echo e($totalSalidas); ?></strong></td>
                    <td><strong><?php echo e($totalStock); ?></strong></td>
                    <td><strong> </strong></td>
                   
                    <td><strong>$<?php echo e(number_format($promedioPrecioCompra, 2)); ?></strong></td>
                    <td><strong>$<?php echo e($totalSaldoCompra); ?></strong></td>
                </tr>
            </tfoot>
        </table>
    <?php endif; ?>

    <br>
    <div class="mt-3">
        <a href="<?php echo e(route('reportes.detalle')); ?>" class="btn btn-secondary">Volver</a>
        <a href="#" class="btn btn-primary">Descargar PDF</a>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Videos\Documentos\ciclo II 2024\sistema-inventario\resources\views/reportes/detalle.blade.php ENDPATH**/ ?>