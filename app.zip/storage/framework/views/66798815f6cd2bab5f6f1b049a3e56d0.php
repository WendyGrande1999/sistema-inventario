

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Gráfico de Productos</h1>
    <canvas id="miGrafico"></canvas>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Obtener los datos del backend
    const productos = <?php echo json_encode($productos, 15, 512) ?>;
    const cantidades = <?php echo json_encode($cantidades, 15, 512) ?>;

    // Configurar el gráfico
    const ctx = document.getElementById('miGrafico').getContext('2d');
    const miGrafico = new Chart(ctx, {
        type: 'bar', // Tipo de gráfico (puede ser 'bar', 'line', 'pie', etc.)
        data: {
            labels: productos,
            datasets: [{
                label: 'Cantidad de Productos',
                data: cantidades,
                backgroundColor: 'rgba(54, 162, 235, 0.5)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: 'Productos en Inventario'
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Videos\Documentos\ciclo II 2024\sistema-inventario\resources\views/grafico/chart.blade.php ENDPATH**/ ?>