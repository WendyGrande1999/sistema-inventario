

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Detalle del Cierre de Inventario</h1>

    <?php if($productosDetalle->isEmpty()): ?>
        <p>No hay datos disponibles para el cierre seleccionado.</p>
    <?php else: ?>
        
       <!-- Mostrar el rango de fechas entre el último cierre y el cierre seleccionado -->
       <p><strong>Rango de Cierre:</strong> Desde <?php echo e($fechaInicioTexto); ?> hasta <?php echo e($fechaCierreTexto); ?></p>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Código</th>
                    <th>Producto</th>
                    <th>Entradas</th>
                    <th>Salidas</th>
                    <th>Ver detalles</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $productosDetalle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($producto['codigo']); ?></td>
                        <td><?php echo e($producto['nombre']); ?></td>
                        <td><?php echo e($producto['entradas']); ?></td>
                        <td><?php echo e($producto['salidas']); ?></td>
                        <td>
                        <a href="<?php echo e(route('entradas.productoCierre', ['fecha_cierre' => $fechaCierre, 'producto' => $producto['id']])); ?>" 
                         class="btn btn-info btn-sm">Ver</a>
                        </td>


                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>


    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Videos\Documentos\ciclo II 2024\sistema-inventario\resources\views/inventario/cierre-detalle.blade.php ENDPATH**/ ?>