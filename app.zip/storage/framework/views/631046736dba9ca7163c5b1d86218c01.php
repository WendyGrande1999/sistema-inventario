

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Seleccionar Producto</h1>

    <!-- Formulario para seleccionar el producto -->
    <form action="<?php echo e(route('reportes.detalle')); ?>" method="GET">
        <div class="form-group">
            <label for="idproducto"><strong>Seleccione un Producto:</strong></label>
            <select name="idproducto" id="idproducto" class="form-control">
                <option value="">Seleccione un producto</option>
                <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($producto->id); ?>">
                        <?php echo e($producto->nombre); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <button type="submit" class="btn btn-primary mt-3">Ver Detalle</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Videos\Documentos\ciclo II 2024\sistema-inventario\resources\views/reportes/select.blade.php ENDPATH**/ ?>