<div class="d-flex align-items-center justify-content-between">
    <a href="index.html" class="logo d-flex align-items-center">
        <img src="assets/img/logo.png" alt="">
        <span class="d-none d-lg-block">Sistema de Inventario</span>
    </a>
    <i class="bi bi-list toggle-sidebar-btn"></i>
</div><!-- End Logo -->

<!-- ======= Buscador ======= -->
<div class="search-bar">
    <form class="search-form d-flex align-items-center" method="POST" action="#">
        <input type="text" name="query" placeholder="Search" title="Enter search keyword">
        <button type="submit" title="Search"><i class="bi bi-search"></i></button>
    </form>
</div><!-- End Search Bar -->


<nav class="header-nav ms-auto">
    <ul class="d-flex align-items-center">

        <li class="nav-item d-block d-lg-none">
            <a class="nav-link nav-icon search-bar-toggle " href="#">
                <i class="bi bi-search"></i>
            </a>
        </li><!-- End Search Icon-->

        <li class="nav-item dropdown">

            <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
                <i class="bi bi-bell"></i>
                <span class="badge bg-primary badge-number"><?php echo e($productosPorAgotarse); ?></span>
            </a><!-- End Notification Icon -->

            <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications">
                <li class="dropdown-header">
                    Tiene <?php echo e($productosPorAgotarse); ?> nuevas notificaciones
                    <a href="#"><span class="badge rounded-pill bg-primary p-2 ms-2">Nuevas</span></a>
                </li>
                <li>
                    <hr class="dropdown-divider">
                </li>
                <?php $__currentLoopData = $dataProductos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($producto['stockTotalActual'] <= 15): ?>
                <li class="notification-item">
                    <i class="bi bi-exclamation-circle text-warning"></i>
                    <div >
                        <h4> <td><?php echo e($producto['nombre']); ?></h4>
                        <p><?php echo e($producto['stockTotalActual']); ?></p>
                        <p><?php echo e($producto['unidad_medida']); ?></p>
                    </div>
                </li>
                <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <hr class="dropdown-divider">
                </li>

                <li class="dropdown-footer">
                    <a href="/inventario/stock">Ver mas notificaciones</a>
                </li>


            </ul><!-- End Notification Dropdown Items -->

        </li><!-- End Notification Nav -->



        <?php if(auth()->guard()->check()): ?>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                    data-bs-toggle="dropdown" aria-expanded="false">

                    <i class="bi bi-person me-2"></i>

                    <?php echo e(Auth::user()->name); ?>

                </a>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                    <li>
                        <a class="dropdown-item" href="<?php echo e(route('profile.show')); ?>">
                            </i> Mi Perfil
                        </a>
                    </li>
                    <li>
                        <hr class="dropdown-divider">
                    </li>
                    <li>
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                            <i class="bi bi-box-arrow-right me-2"></i> Cerrar Sesión
                        </a>
                    </li>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                </ul>
            </li>
        <?php endif; ?>

        <!-- Opción para iniciar sesión si no está autenticado -->
        <?php if(auth()->guard()->guest()): ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('login')); ?>">Iniciar Sesión</a>
            </li>
        <?php endif; ?>

    </ul>
</nav><!-- End Icons Navigation -->
<?php /**PATH C:\Users\PC\Videos\Documentos\ciclo II 2024\sistema-inventario\resources\views/partials/nav.blade.php ENDPATH**/ ?>