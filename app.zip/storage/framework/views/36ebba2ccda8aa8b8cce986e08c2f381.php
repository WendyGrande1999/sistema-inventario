<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Detalle de Entrada <?php echo e($entrada->id); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 100%;
            padding: 20px;
        }
        .title {
            text-align: center;
            font-size: 24px;
            margin-bottom: 20px;
            font-weight: bold;
        }
        .card {
            border: 1px solid #ccc;
            padding: 20px;
            margin-bottom: 20px;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .table th, .table td {
            border: 1px solid #ccc;
            padding: 8px;
            text-align: left;
        }
        .table th {
            background-color: #f2f2f2;
        }
        .summary {
            margin-top: 20px;
            font-size: 18px;
        }
        .text-center {
            text-align: center;
        }
        .total {
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="title">
            Detalle de Compra 
        </div>
        
        <div class="card">
            <h3>Información General</h3>
            <p><strong>Fecha de Ingreso:</strong> <?php echo e($entrada->fecha_ingreso); ?></p>
            <p><strong>Producto:</strong> <?php echo e($entrada->producto->nombre); ?></p>
            <p><strong>Proveedor:</strong> <?php echo e($entrada->proveedor->name); ?></p>
            <p><strong>Usuario Responsable:</strong> <?php echo e($entrada->usuario->name); ?></p>
        </div>

        <div class="card">
            <h3>Detalles de la Entrada</h3>
            <table class="table">
                <thead>
                    <tr>
                        <th>Cantidad Entrante</th>
                        <th>Salidas</th>
                        <th>Cantidad Disponible</th>
                      
                        <th>Precio por Unidad</th>
                        <th>Saldo Compra</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php echo e($entrada->cantidad_entrante); ?></td>
                        <td><?php echo e($entrada->salida); ?></td>
                        <td><?php echo e($entrada->cantidad); ?> <?php echo e($entrada->unidad_medida); ?></td>
                     
                        <td>$<?php echo e($entrada->precio_unidad); ?></td>
                        <td>$<?php echo e($entrada->saldo_compra); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="card">
            <h3>Detalle de Salidas</h3>
            <table class="table">
                <thead>
                    <tr>
                        <th>Fecha de Salida</th>
                        <th>Cantidad</th>
                        <th>Unidad de Medida</th>
                        <th>Usuario</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $entrada->salidas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salida): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($salida->fecha_salida); ?></td>
                            <td><?php echo e($salida->cantidad); ?></td>
                            <td><?php echo e($salida->unidad_medida); ?></td>
                            <td><?php echo e($salida->usuario->name); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="text-center">No hay salidas registradas para esta entrada.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <p class="summary total">Total de Salidas: <?php echo e($entrada->salidas->sum('cantidad')); ?></p>
        </div>

    </div>
</body>
</html>
<?php /**PATH C:\Users\PC\Videos\Documentos\ciclo II 2024\sistema-inventario\resources\views/entradas/show_pdf.blade.php ENDPATH**/ ?>