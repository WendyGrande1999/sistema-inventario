

<?php $__env->startSection('content'); ?>
<div class="container">
<h3>Reporte Diario de Inventario - <?php echo e($fechaTexto); ?></h3>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th class="bg-success">Código</th>
                <th class="bg-success">Producto</th>
                <th class="bg-success">Entradas</th>
                <th class="bg-success">Salidas</th>
                <th class="bg-success">Stock</th>
                <th class="bg-success">Unit de medida</th>
                <th class="bg-success">Costo total entradas</th>
                <th class="bg-success">Total Egreso</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $reporte; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item['codigo']); ?></td>
                    <td><?php echo e($item['producto']); ?></td>
                    <td><?php echo e($item['entradas']); ?></td>
                    <td><?php echo e($item['salidas']); ?></td>
                    <td><?php echo e($item['stock']); ?></td>
                    <td><?php echo e($item['unidad_medida']); ?></td>
                    <td>$<?php echo e(number_format($item['costo_por_producto'], 2)); ?></td>
                    <td>$<?php echo e(number_format($item['total_egreso'], 2)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
            <tr>
                <th colspan="2">Totales</th>
                <th><?php echo e($totalEntradas); ?></th>
                <th><?php echo e($totalSalidas); ?></th>
                <th></th>
                <th></th>
                <th>$<?php echo e(number_format($totalCosto, 2)); ?></th>
                <th>$<?php echo e(number_format($totalEgresos, 2)); ?></th>
            </tr>
        </tfoot>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Videos\Documentos\ciclo II 2024\sistema-inventario\resources\views/reportes/reporte-diario.blade.php ENDPATH**/ ?>