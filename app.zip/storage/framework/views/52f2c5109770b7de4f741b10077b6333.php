<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Editar Entrada</h1>

     <!-- Contenedor para mensajes de error con JavaScript -->
     <div id="error-message" class="alert alert-danger d-none"></div>

    <form action="<?php echo e(route('entradas.update', $entrada->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <strong>
                    <label for="fecha_ingreso">Fecha:</label>
                    </strong>
                    <input type="date" name="fecha_ingreso" id="fecha_ingreso" class="form-control" value="<?php echo e($entrada->fecha_ingreso); ?>" required>
                </div>
                <br>

                <div class="form-group">
                    <strong>
                    <label for="idproducto">Producto</label>
                    </strong>
                    <select name="idproducto" id="idproducto" class="form-control" required>
                        <option value="">Seleccione un producto</option>
                        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($producto->id); ?>" <?php echo e($producto->id == $entrada->idproducto ? 'selected' : ''); ?>>
                                <?php echo e($producto->nombre); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <br>

                <div class="form-group">
                    <strong>
                    <label for="idproveedor">Proveedor</label>
                    </strong>
                    <select name="idproveedor" id="idproveedor" class="form-control" required>
                        <option value="">Seleccione un proveedor</option>
                        <?php $__currentLoopData = $proveedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proveedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($proveedor->id); ?>" <?php echo e($proveedor->id == $entrada->idproveedor ? 'selected' : ''); ?>>
                                <?php echo e($proveedor->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <br>

                
            </div>

            <div class="col-md-6">
                <div class="form-group">
                    <strong>
                    <label for="cantidad_entrante">Cantidad</label>
                    </strong>
                    <input type="number" name="cantidad_entrante" id="cantidad_entrante" class="form-control" value="<?php echo e($entrada->cantidad_entrante); ?>" step="0.01" required>
                </div>
                <br>

                <div class="form-group">
                    <strong>
                    <label for="precio_unidad">Precio por Unidad</label>
                    </strong>
                    <input type="number" name="precio_unidad" id="precio_unidad" class="form-control" value="<?php echo e($entrada->precio_unidad); ?>" step="0.01" required>
                </div>
                <br>

                <div class="form-group">
                    <strong>
                    <label for="saldo_compra">Saldo Compra</label>
                    </strong>
                    <input type="number" name="saldo_compra" id="saldo_compra" class="form-control" value="<?php echo e($entrada->saldo_compra); ?>" step="0.01" required>
                </div>
            </div>
        </div>

        <br>


        <div class="d-flex justify-content-start gap-2">
    <a href="<?php echo e(route('entradas.index')); ?>" class="btn btn-secondary">Volver a la Lista</a>
    <button type="submit" class="btn btn-primary">Guardar Cambios</button>
</div>

   
    </form>

    <script>
    // Comprobar si existen errores en la sesión
    <?php if($errors->any()): ?>
        let errorMessage = <?php echo json_encode($errors->first(), 15, 512) ?>; // Obtener el primer mensaje de error
        let errorContainer = document.getElementById('error-message');
        
        // Mostrar el mensaje de error
        errorContainer.textContent = errorMessage;
        errorContainer.classList.remove('d-none'); // Hacer visible la alerta
    <?php endif; ?>
</script>


    <script>
      document.addEventListener('DOMContentLoaded', function() {
          const cantidadInput = document.getElementById('cantidad');
          const precioUnidadInput = document.getElementById('precio_unidad');
          const saldoCompraInput = document.getElementById('saldo_compra');

          function calcularSaldoCompra() {
              const cantidad = parseFloat(cantidadInput.value) || 0;
              const precioUnidad = parseFloat(precioUnidadInput.value) || 0;
              saldoCompraInput.value = (cantidad * precioUnidad).toFixed(2);
          }

          cantidadInput.addEventListener('input', calcularSaldoCompra);
          precioUnidadInput.addEventListener('input', calcularSaldoCompra);
      });
  </script>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Videos\Documentos\ciclo II 2024\sistema-inventario\resources\views/entradas/edit.blade.php ENDPATH**/ ?>