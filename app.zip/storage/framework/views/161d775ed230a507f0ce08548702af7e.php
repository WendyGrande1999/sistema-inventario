

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Editar Roles de <?php echo e($user->name); ?></h1>
    <form action="<?php echo e(route('admin.users.roles.assign', $user)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="roles">Roles</label>
            <select name="roles[]" id="roles" class="form-control" multiple>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($role->name); ?>" <?php echo e($user->hasRole($role->name) ? 'selected' : ''); ?>>
                    <?php echo e($role->name); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <button type="submit" class="btn btn-success">Asignar Roles</button>
        <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-secondary">Volver</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Videos\Documentos\ciclo II 2024\sistema-inventario\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>