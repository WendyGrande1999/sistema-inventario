<?php $__env->startSection('content'); ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('role', 'admin')): ?>
        <div class="container">

            <h1>Lista de Entradas</h1>
            <a href="<?php echo e(route('entradas.create')); ?>" class="btn btn-primary mb-3">Agregar Entrada</a>

            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>

    <!-- Tabla para las entradas desde el ultimo cierre a la fecha  -->  
<br>

 <!-- Tabla para las entradas desde el último cierre a la fecha -->
 <div class="card mb-4">
            <div class="card-header bg-success text-white">
                <h3 class="mb-0">Entradas Activas desde el Último Cierre</h3>
            </div>
    <div class="card-body">
        <div class="table-responsive">
    
        <div class="card-body">
        <table id="my-table"  class="table table-bordered" width="100%" cellspacing="0">
        <thead>
            <tr>
              
                <th>Fecha Ingreso</th>
                <th>Producto</th>
                <th>Proveedor</th>
                <th>Usuario</th>
                <th>Cantidad entrante</th>
                <th>Cantidad disponible</th>
                <th>Salida</th>
                <th>Precio por Unidad</th>
                <th>Saldo Compra</th>
                <th>Ver</th>
                <th>Edit</th>
                <th>Eliminar</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $entradasDesdeUltimoCierre; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entrada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              
                <td><?php echo e($entrada->fecha_ingreso); ?></td>
                <td><?php echo e($entrada->producto->nombre); ?></td>
                <td><?php echo e($entrada->proveedor->name); ?></td>
                <td><?php echo e($entrada->usuario->name); ?></td>
                
                <td><?php echo e($entrada->cantidad_entrante); ?></td>
                <td><?php echo e($entrada->cantidad); ?> <?php echo e($entrada->unidad_medida); ?></td>
                <td><?php echo e($entrada->salida); ?></td>
                <td>$<span><?php echo e($entrada->precio_unidad); ?></span> 
                
                <td>$<span><?php echo e($entrada->saldo_compra); ?></span></td>

                
                
                <td>
                    <a href="<?php echo e(route('entradas.show', $entrada->id)); ?>" class="btn btn-info btn-sm">
                        Ver</a>
              
                </td>

                                            <td>
                                                <a href="<?php echo e(route('entradas.edit', $entrada->id)); ?>"
                                                    class="btn btn-warning btn-sm">Editar</a>
                                            </td>

                                            <td>



                                                <form id="delete-entry-form"
                                                    action="<?php echo e(route('entradas.destroy', $entrada->id)); ?>" method="POST"
                                                    style="display: inline;">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button onclick="eliminarEntrada(event)" type="button"
                                                        class="btn btn-danger btn-sm">Eliminar</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

  <!-- Tabla para las entradas del ultimo cierre  -->  
<br>
<br>

<div class="card mb-4">
            <div class="card-header bg-secondary text-white">
               <strong> <h3> Entradas inactivas desde el ultimo cierre a la fecha.</h3></strong>
            </div>
    <div class="card-body">
        <div class="table-responsive">
    
        <div class="card-body">
        <table id="my-table"  class="table table-bordered" width="100%" cellspacing="0">
        <thead>
            <tr>
              
                <th>Fecha Ingreso</th>
                <th>Producto</th>
                <th>Proveedor</th>
                <th>Usuario</th>
               
                <th>Cantidad entrante</th>
                <th>Cantidad disponible</th>
              
                <th>Salida</th>
                <th>Precio por Unidad</th>
                <th>Saldo Compra</th>
                <th>Ver</th>
                <th>Edit</th>
                <th>Eliminar</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $entradasDesdeUltimoCierreInactivas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entrada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              
                <td><?php echo e($entrada->fecha_ingreso); ?></td>
                <td><?php echo e($entrada->producto->nombre); ?></td>
                <td><?php echo e($entrada->proveedor->name); ?></td>
                
                <td><?php echo e($entrada->usuario->name); ?></td>
               
                <td><?php echo e($entrada->cantidad_entrante); ?></td>
                <td><?php echo e($entrada->cantidad); ?> <?php echo e($entrada->unidad_medida); ?></td>
                <td><?php echo e($entrada->salida); ?></td>
                <td>$<span><?php echo e($entrada->precio_unidad); ?></span> 
                
                <td>$<span><?php echo e($entrada->saldo_compra); ?></span></td>

                
                
                <td>
                    <a href="<?php echo e(route('entradas.show', $entrada->id)); ?>" class="btn btn-info btn-sm">
                        Ver</a>
              
                </td>

                                            <td>
                                                <a href="<?php echo e(route('entradas.edit', $entrada->id)); ?>"
                                                    class="btn btn-warning btn-sm">Editar</a>
                                            </td>

                                            <td>



                                                <form id="delete-entry-form"
                                                    action="<?php echo e(route('entradas.destroy', $entrada->id)); ?>" method="POST"
                                                    style="display: inline;">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button onclick="eliminarEntrada(event)" type="button"
                                                        class="btn btn-danger btn-sm">Eliminar</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>


 <br>

            <!-- Scripts -->
            <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
            <script src="https://cdn.datatables.net/1.13.0/js/jquery.dataTables.min.js"></script>
            <script src="https://cdn.datatables.net/1.13.0/js/dataTables.bootstrap5.min.js"></script>


            <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
            <script>
                function eliminarEntrada(event) {
                    event.preventDefault(); // Evitar el envío automático del formulario

                    Swal.fire({
                        title: '¿Estás seguro que deseas eliminar este registro?',
                        text: '¡No podrás revertir esta acción!',
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Sí, eliminar'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            // Enviar el formulario de eliminación
                            document.getElementById('delete-entry-form').submit();
                        }
                    });
                }
            </script>

            <!-- Script para inicializar DataTables -->
            <script>
                $(document).ready(function() {
                    $('#my-table').DataTable({
                        "paging": true,
                        "searching": true,
                        "ordering": true,
                        "info": true,
                        "lengthChange": true,
                        "pageLength": 4,
                        "language": {
                            "processing": "Procesando...",
                            "lengthMenu": "Mostrar _MENU_ registros por página",
                            "zeroRecords": "No se encontraron resultados",
                            "info": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_",
                            "infoEmpty": "Mostrando 0 registros",
                            "infoFiltered": "(filtrado de _MAX_ registros)",
                            "paginate": {
                                "first": "Primero",
                                "last": "Último",
                                "next": "Siguiente",
                                "previous": "Anterior"
                            },
                            "search": "Buscar:"
                        }
                    });
                });
            </script>

        </div>
    <?php endif; ?>
    <?php if (\Illuminate\Support\Facades\Blade::check('role', 'editor')): ?>
        <div class="container">

            <h1>Lista de Entradas</h1>
            <a href="<?php echo e(route('entradas.create')); ?>" class="btn btn-primary mb-3">Agregar Entrada</a>

            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>

            <!-- Tabla para las entradas desde el ultimo cierre a la fecha  -->
            <br>
            <div class="card-body">
                <div class="table-responsive">


                    
                    <div class="card mb-4">
                        <div class="card-header bg-success text-white">
                            <h3 class="mb-0">Entradas Activas desde el Último Cierre</h3>
                        </div>
                        <div class="card-body">
                            <table id="my-table" class="table table-bordered" width="100%" cellspacing="0">
                                <thead>
                                    <tr>

                                        <th>Fecha Ingreso</th>
                                        <th>Producto</th>
                                        <th>Proveedor</th>
                                        <th>Usuario</th>
                                        <th>Unidad de Medida</th>
                                        <th>Cantidad entrante</th>
                                        <th>Cantidad disponible</th>

                                        <th>Salida</th>
                                        <th>Precio por Unidad</th>
                                        <th>Saldo Compra</th>
                                        <th>Ver</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $entradasDesdeUltimoCierre; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entrada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>

                                            <td><?php echo e($entrada->fecha_ingreso); ?></td>
                                            <td><?php echo e($entrada->producto->nombre); ?></td>
                                            <td><?php echo e($entrada->proveedor->name); ?></td>

                                            <td><?php echo e($entrada->usuario->name); ?></td>
                                            <td><?php echo e($entrada->unidad_medida); ?></td>
                                            <td><?php echo e($entrada->cantidad_entrante); ?></td>
                                            <td><?php echo e($entrada->cantidad); ?></td>
                                            <td><?php echo e($entrada->salida); ?></td>
                                            <td>$<span><?php echo e($entrada->precio_unidad); ?></span>

                                            <td>$<span><?php echo e($entrada->saldo_compra); ?></span></td>

                                            <td>
                                                <a href="<?php echo e(route('entradas.show', $entrada->id)); ?>"
                                                    class="btn btn-info btn-sm">
                                                    Ver</a>

                                            </td>
                                            <td>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Tabla para las entradas del ultimo cierre  -->
            <br>
            <br>

            <div class="card-body">
                <div class="table-responsive">
                    <strong>
                        <h3> Entradas inactivas desde el ultimo cierre a la fecha.</h3>
                    </strong>
                    <br>
                    <table id="my-table" class="table table-bordered" width="100%" cellspacing="0">
                        <thead>
                            <tr>

                                <th>Fecha Ingreso</th>
                                <th>Producto</th>
                                <th>Proveedor</th>
                                <th>Usuario</th>
                                <th>Unidad de Medida</th>
                                <th>Cantidad entrante</th>
                                <th>Cantidad disponible</th>

                                <th>Salida</th>
                                <th>Precio por Unidad</th>
                                <th>Saldo Compra</th>
                                <th>Ver</th>
                                <th>Edit</th>
                                <th>Eliminar</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $entradasDesdeUltimoCierreInactivas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entrada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>

                                    <td><?php echo e($entrada->fecha_ingreso); ?></td>
                                    <td><?php echo e($entrada->producto->nombre); ?></td>
                                    <td><?php echo e($entrada->proveedor->name); ?></td>

                                    <td><?php echo e($entrada->usuario->name); ?></td>
                                    <td><?php echo e($entrada->unidad_medida); ?></td>
                                    <td><?php echo e($entrada->cantidad_entrante); ?></td>
                                    <td><?php echo e($entrada->cantidad); ?></td>
                                    <td><?php echo e($entrada->salida); ?></td>
                                    <td>$<span><?php echo e($entrada->precio_unidad); ?></span>

                                    <td>$<span><?php echo e($entrada->saldo_compra); ?></span></td>



                                    <td>
                                        <a href="<?php echo e(route('entradas.show', $entrada->id)); ?>"
                                            class="btn btn-info btn-sm">Ver</a>

                                    </td>

                                    <td>
                                        <a href="<?php echo e(route('entradas.edit', $entrada->id)); ?>"
                                            class="btn btn-warning btn-sm">Editar</a>
                                    </td>

                                    <td>



                                        <form id="delete-entry-form" action="<?php echo e(route('entradas.destroy', $entrada->id)); ?>"
                                            method="POST" style="display: inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button onclick="eliminarEntrada(event)" type="button"
                                                class="btn btn-danger btn-sm">Eliminar</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Scripts -->
            <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
            <script src="https://cdn.datatables.net/1.13.0/js/jquery.dataTables.min.js"></script>
            <script src="https://cdn.datatables.net/1.13.0/js/dataTables.bootstrap5.min.js"></script>


            <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
            <script>
                function eliminarEntrada(event) {
                    event.preventDefault(); // Evitar el envío automático del formulario

                    Swal.fire({
                        title: '¿Estás seguro que deseas eliminar este registro?',
                        text: '¡No podrás revertir esta acción!',
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        confirmButtonText: 'Sí, eliminar'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            // Enviar el formulario de eliminación
                            document.getElementById('delete-entry-form').submit();
                        }
                    });
                }
            </script>

            <!-- Script para inicializar DataTables -->
            <script>
                $(document).ready(function() {
                    $('#my-table').DataTable({
                        "paging": true,
                        "searching": true,
                        "ordering": true,
                        "info": true,
                        "lengthChange": true,
                        "pageLength": 4,
                        "language": {
                            "processing": "Procesando...",
                            "lengthMenu": "Mostrar _MENU_ registros por página",
                            "zeroRecords": "No se encontraron resultados",
                            "info": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_",
                            "infoEmpty": "Mostrando 0 registros",
                            "infoFiltered": "(filtrado de _MAX_ registros)",
                            "paginate": {
                                "first": "Primero",
                                "last": "Último",
                                "next": "Siguiente",
                                "previous": "Anterior"
                            },
                            "search": "Buscar:"
                        }
                    });
                });
            </script>

        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Videos\Documentos\ciclo II 2024\sistema-inventario\resources\views/entradas/index.blade.php ENDPATH**/ ?>