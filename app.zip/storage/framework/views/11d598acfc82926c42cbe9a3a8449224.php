

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Reporte Diario de Inventario</h1>

    <!-- Formulario para seleccionar la fecha -->
    <form action="<?php echo e(route('reporte-diario.generar')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="fecha">Seleccionar Fecha:</label>
            <input type="date" id="fecha" name="fecha" class="form-control" required>
        </div>
        <br>
        <button type="submit" class="btn btn-primary">Generar Reporte</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Videos\Documentos\ciclo II 2024\sistema-inventario\resources\views/reportes/diario.blade.php ENDPATH**/ ?>