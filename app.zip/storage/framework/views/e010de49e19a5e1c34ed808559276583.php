Prueba de subir cambios a git
<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Agregar usuario</h1>
    <br>
                                <form action="<?php echo e(route('users.store')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>

                                    <!-- Mostrar mensajes de éxito -->
                                    <?php if(session('success')): ?>
                                        <div class="alert alert-success">
                                            <?php echo e(session('success')); ?>

                                        </div>
                                    <?php endif; ?>

                                    <!-- Mostrar mensajes de error -->
                                    <?php if($errors->any()): ?>
                                        <div class="alert alert-danger">
                                            <ul>
                                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($error); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    <?php endif; ?>

                                    <div class="form-outline mb-4">
                                        <label class="form-label" for="name">Nombre</label>
                                        <input type="text" name="name" id="name" class="form-control" placeholder="Nombre" required />
                                    </div>

                                    <div class="form-outline mb-4">
                                        <label class="form-label" for="email">Correo</label>
                                        <input type="email" name="email" id="email" class="form-control" placeholder="Correo electrónico" required />
                                    </div>

                                    <div class="form-outline mb-4">
                                        <label class="form-label" for="password">Contraseña</label>
                                        <input type="password" name="password" id="password" class="form-control" required />
                                    </div>

                                    <div class="form-outline mb-4">
                                        <label class="form-label" for="password_confirmation">Confirmar Contraseña</label>
                                        <input type="password" name="password_confirmation" id="password_confirmation" class="form-control" required />
                                    </div>

                                    <div class="text-center pt-1 mb-5 pb-1">
                                        <button class="btn btn-primary btn-block fa-lg gradient-custom-2 mb-3" type="submit">Agregar Usuario</button>
                                    </div>
                                </form>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Videos\Documentos\ciclo II 2024\sistema-inventario\resources\views/admin/users/create.blade.php ENDPATH**/ ?>