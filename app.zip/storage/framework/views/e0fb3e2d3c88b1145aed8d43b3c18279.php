

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Editar Salida</h1>
    <form action="<?php echo e(route('salidas.update', $salida->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        
        <div class="form-group">
            <label for="fecha_salida"><strong>Fecha de Salida</strong></label>
            <input type="date" name="fecha_salida" id="fecha_salida" class="form-control" value="<?php echo e($salida->fecha_salida); ?>" required>
        </div>
        <br>

       
    
      
        <div class="form-group">
            <label for="cantidad"><strong>Cantidad</strong></label>
            <input type="number" name="cantidad" id="cantidad" class="form-control" value="<?php echo e($salida->cantidad); ?>" required>
        </div>
        <br>

        <button type="submit" class="btn btn-primary">Actualizar Salida</button>
        <a href="<?php echo e(route('salidas.index')); ?>" class="btn btn-secondary">Cancelar</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Videos\Documentos\ciclo II 2024\sistema-inventario\resources\views/salidas/edit.blade.php ENDPATH**/ ?>