<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Detalle de compra </h1>
  
    <div class="card">
        <div class="card-body">
            <h4 class="card-title">Fecha de Ingreso: <?php echo e($entrada->fecha_ingreso); ?></h4>

            <p class="card-text"><strong>Producto:</strong> <?php echo e($entrada->producto->nombre); ?></p>
            <p class="card-text"><strong>Proveedor:</strong> <?php echo e($entrada->proveedor->name); ?></p>
            <p class="card-text"><strong>Usuario:</strong> <?php echo e($entrada->usuario->name); ?></p>
           
            <table class="table table-bordered mt-4">
                <thead>
                    <tr>
                        <th>Cantidad Entrante</th>
                        <th>Salidas</th>
                        <th>Cantidad Disponible</th>
                        <th>Unidad de Medida</th>
                        <th>Precio por Unidad</th>
                        <th>Saldo Compra</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php echo e($entrada->cantidad_entrante); ?></td>
                        <td><?php echo e($entrada->salida); ?></td>
                        <td><?php echo e($entrada->cantidad); ?></td>
                        <td><?php echo e($entrada->unidad_medida); ?></td>
                        <td>$<?php echo e($entrada->precio_unidad); ?></td>
                        <td>$<?php echo e($entrada->saldo_compra); ?></td>
                    </tr>
                    
                </tbody>
            </table>

            <br>

            <h4 class="card-title">Detalle de salidas</h4>

            <!-- Tabla con el registro de todas las salidas de esta entrada -->
            <table class="table table-bordered mt-4">
                <thead>
                    <tr>
                        <th>Fecha de Salida</th>
                        <th>Cantidad</th>
                        <th>Unidad de Medida</th>
                        <th>Usuario</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $entrada->salidas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salida): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($salida->fecha_salida); ?></td>
                            <td><?php echo e($salida->cantidad); ?></td>
                            <td><?php echo e($salida->unidad_medida); ?></td>
                            <td><?php echo e($salida->usuario->name); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="text-center">No hay salidas registradas para esta entrada.</td>
                        </tr>
                    <?php endif; ?>

                    <tr>
                        <td>
                        <p><strong>Total:</strong></p> 
                        </td> 
                        <td>
                         <?php echo e($sumSalida); ?>

                        </td> 
                    </tr>
                    
                </tbody>
            </table>

        </div>
    </div>

    <br>
    <div class="mt-3">
        <a href="<?php echo e(route('entradas.index')); ?>" class="btn btn-secondary">Volver a la Lista</a>
        <a href="<?php echo e(route('entradas.pdf', $entrada->id)); ?>" class="btn btn-primary">Descargar PDF</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Videos\Documentos\ciclo II 2024\sistema-inventario\resources\views/entradas/show.blade.php ENDPATH**/ ?>