<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Reporte de Stock</h1>

        <!-- Mostrar la fecha del último cierre -->
        <?php if($fechaUltimoCierre !== 'No hay cierres anteriores'): ?>
            <p><strong>Último cierre realizado:</strong> <?php echo e($fechaUltimoCierre); ?></p>
            <p>El stock mostrado refleja los movimientos desde el último cierre hasta la fecha actual.</p>
        <?php else: ?>
            <p>No se ha realizado ningún cierre de inventario hasta la fecha.</p>
        <?php endif; ?>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Código</th>
                    <th>Producto</th>
                    <th>Stock entrante</th>
                    <th>Entradas</th>
                    <th>Salidas</th>
                    <th class="bg-warning">Stock Actual</th>

                    <th>Unidad de Medida</th>

                </tr>
            </thead>
            <tbody>
                <?php if($data->isEmpty()): ?>
                    <tr>
                        <td colspan="5" class="text-center">No hay datos disponibles.</td>
                    </tr>
                <?php else: ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <!-- Mostrar la cantidad de productos que están por agotarse -->
                        <?php if($producto['stockTotalActual'] <= 15 ): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <strong> El producto: <?php echo e($producto['nombre_producto']); ?> esta por agotarse solo queda un :
                                    <?php echo e($producto['stockTotalActual']); ?>%
                                    <button type="button" class="btn-close" data-bs-dismiss="alert"
                                        aria-label="Close"></button>
                            </div>
                        <?php endif; ?>

                        <tr>
                            <td><?php echo e($producto['codigo']); ?></td>
                            <td><?php echo e($producto['nombre_producto']); ?></td>
                            <td><?php echo e($producto['stock_ultimo_cierre']); ?></td>
                            <td><?php echo e($producto['cantidad_entradas_desde_cierre']); ?></td>
                            <td><?php echo e($producto['cantidad_salidas_desde_cierre']); ?></td>


                            <?php if($producto['stockTotalActual'] <= 15): ?>
                                <td class="bg-danger "><?php echo e($producto['stockTotalActual']); ?></td>
                            <?php elseif($producto['stockTotalActual'] > 15): ?>
                                <td class="bg-warning"><?php echo e($producto['stockTotalActual']); ?></td>
                            <?php endif; ?>
                            <td><?php echo e($producto['unidad_medida']); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Videos\Documentos\ciclo II 2024\sistema-inventario\resources\views/inventario/stock.blade.php ENDPATH**/ ?>