

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Cierre de Inventario</h1>

    <!-- Mostrar mensaje de éxito si el cierre se generó correctamente -->
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <br>
    <p>Haz clic en el botón para generar un cierre de inventario. Este proceso actualizará el stock de todos los productos en el sistema.</p>

    <form action="<?php echo e(route('inventario.generar-cierre')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <!-- Campo de selección de fecha -->
        <div class="form-group">
            <label for="fecha_cierre">Seleccionar fecha de Cierre:</label>
            <input type="date" id="fecha_cierre" name="fecha_cierre" class="form-control" required>
        </div>

        <br>

        <!-- Botón para generar el cierre manual -->
        <button type="submit" class="btn btn-primary btn-lg">Generar Cierre de Inventario</button>
    </form>

    <br>

    <!-- Mostrar la tabla de productos con su stock actual -->
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Código</th>
                <th>Nombre</th>
                <th>Stock Actual</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $dataProductos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($producto['codigo']); ?></td>
                <td><?php echo e($producto['nombre']); ?></td>
                <td><?php echo e($producto['stockTotalActual']); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Videos\Documentos\ciclo II 2024\sistema-inventario\resources\views/inventario/cierre-manual.blade.php ENDPATH**/ ?>