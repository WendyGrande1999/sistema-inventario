<table id="my-table" class="table table-bordered table-hover" width="100%" cellspacing="0">
    <thead class="table-dark">
        <tr>
            <th>Fecha Ingreso</th>
            <th>Producto</th>
            <th>Proveedor</th>
            <th>Usuario</th>
            <th>Unidad de Medida</th>
            <th>Cantidad Entrante</th>
            <th>Cantidad Disponible</th>
            <th>Salida</th>
            <th>Precio por Unidad</th>
            <th>Saldo Compra</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $entradas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entrada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($entrada->fecha_ingreso); ?></td>
                <td><?php echo e($entrada->producto->nombre); ?></td>
                <td><?php echo e($entrada->proveedor->name); ?></td>
                <td><?php echo e($entrada->usuario->name); ?></td>
                <td><?php echo e($entrada->unidad_medida); ?></td>
                <td><?php echo e($entrada->cantidad_entrante); ?></td>
                <td><?php echo e($entrada->cantidad); ?></td>
                <td><?php echo e($entrada->salida); ?></td>
                <td>$<?php echo e($entrada->precio_unidad); ?></td>
                <td>$<?php echo e($entrada->saldo_compra); ?></td>
                <td>
                    <div class="btn-group" role="group">
                        <a href="<?php echo e(route('entradas.show', $entrada->id)); ?>" class="btn btn-info btn-sm">
                            <i class="fas fa-eye"></i> Ver
                        </a>
                        <a href="<?php echo e(route('entradas.edit', $entrada->id)); ?>" class="btn btn-warning btn-sm">
                            <i class="fas fa-edit"></i> Editar
                        </a>
                        <form action="<?php echo e(route('entradas.destroy', $entrada->id)); ?>" method="POST" style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button onclick="eliminarEntrada(event)" type="button" class="btn btn-danger btn-sm">
                                <i class="fas fa-trash-alt"></i> Eliminar
                            </button>
                        </form>
                    </div>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\Users\PC\Videos\Documentos\ciclo II 2024\sistema-inventario\resources\views/partials/entradas-table.blade.php ENDPATH**/ ?>