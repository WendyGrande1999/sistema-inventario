

<?php $__env->startSection('content'); ?>
<div class="container">
    <h3>Seleccionar Fechas para el Reporte de Inventario</h3>
    <form action="<?php echo e(route('reportes.reportePorFechas')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-md-6">
                <label for="fecha_inicio">Fecha de Inicio</label>
                <input type="date" name="fecha_inicio" class="form-control" required>
            </div>
            <div class="col-md-6">
                <label for="fecha_cierre">Fecha de Cierre</label>
                <input type="date" name="fecha_cierre" class="form-control" required>
            </div>
        </div>
        <br>
        <button type="submit" class="btn btn-primary">Generar Reporte</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Videos\Documentos\ciclo II 2024\sistema-inventario\resources\views/reportes/seleccionar-fechas.blade.php ENDPATH**/ ?>