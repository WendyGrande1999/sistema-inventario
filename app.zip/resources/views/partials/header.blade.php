<!-- resources/views/partials/header.blade.php -->
<center><h3>HOSTAL HOJAS ECO-VILLA</h3></center>